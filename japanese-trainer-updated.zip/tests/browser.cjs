// Real-browser regression suite. Requires npm ci and a Playwright browser installation.
const assert = require('node:assert/strict');
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const {chromium, webkit} = require('playwright');
const root = path.resolve(__dirname, '..');
const output = path.join(root, 'test-results');
const mime = {'.html':'text/html', '.js':'text/javascript', '.css':'text/css'};
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const name = pathname === '/' ? 'index.html' : pathname.slice(1);
  const file = path.resolve(root, name);
  if (!file.startsWith(root + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.writeHead(404); res.end(); return;
  }
  res.setHeader('Content-Type', mime[path.extname(file)] || 'application/octet-stream');
  res.end(fs.readFileSync(file));
});
const lessons = ['group1','group2','group3','iadj','naadj','noun'];
const sizes = [[320,568],[568,320],[390,844],[844,390],[768,1024],[1024,768],[1440,900],[1024,480]];
async function main() {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const url = `http://127.0.0.1:${server.address().port}/`;
  const type = process.env.BROWSER === 'webkit' ? webkit : chromium;
  const executablePath = process.env.BROWSER === 'webkit' ? process.env.WEBKIT_PATH : process.env.CHROMIUM_PATH;
  const browser = await type.launch({headless:true, ...(executablePath ? {executablePath} : {})});
  fs.mkdirSync(output, {recursive:true});
  try {
    const context = await browser.newContext({reducedMotion:'reduce'});
    const page = await context.newPage();
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.goto(url);
    for (const lang of ['ru','uz']) {
      await page.locator(`[data-lang="${lang}"]`).click();
      for (const [width,height] of sizes) {
        await page.setViewportSize({width,height});
        for (const scale of [1,2]) {
          await page.evaluate(s => document.documentElement.style.fontSize = `${s * 100}%`, scale);
          for (const lesson of lessons) {
            await page.locator('#lesson-select').selectOption(lesson);
            const region = page.locator(`#theory-${lesson}`);
            assert.ok(await region.isVisible());
            assert.equal(await region.locator('details, .plain-cell').count(), 0);
            assert.ok(await region.locator('table').count() > 0);
            assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth + 1), false,
              `${lang}/${lesson}/${width}x${height}/${scale}: page overflow`);
            const errorsInTables = await region.locator('table').evaluateAll(tables => tables.flatMap(table => {
              const headers = [...table.querySelectorAll('thead th')];
              const issues = [];
              if (headers.length !== 3 || headers.some(h => h.scope !== 'col' || getComputedStyle(h).display === 'none')) issues.push('column headers');
              if (table.classList.contains('form-matrix') && (!table.caption || table.querySelectorAll('tbody th[scope="row"]').length !== 2)) issues.push('matrix labels');
              return issues;
            }));
            assert.deepEqual(errorsInTables, []);
          }
          if ((width === 320 || width === 1440) && scale === 2) {
            await page.locator('#lesson-select').selectOption('group1');
            await page.screenshot({path:path.join(output, `${lang}-${width}-text200.png`), fullPage:true});
          }
        }
      }
    }
    await page.setViewportSize({width:390,height:844});
    await page.evaluate(() => document.documentElement.style.fontSize = '100%');
    await page.locator('[data-lang="ru"]').click();
    await page.locator('#lesson-select').selectOption('group1');
    await page.locator('[data-lesson-practice="kaku"]').click();
    await page.clock.install({time:new Date('2026-10-22T12:00:00Z')});
    const wrong = await page.evaluate(() => practiceState.currentOptions.find(o => !o.isCorrect).id);
    await page.locator(`[data-option-id="${wrong}"]`).press('Enter');
    assert.ok(await page.locator('#explanation-box').isVisible());
    assert.equal(await page.locator('#next-btn').isDisabled(), true);
    await page.clock.runFor(4999);
    assert.equal(await page.locator('#next-btn').isDisabled(), true);
    assert.equal(await page.evaluate(() => practiceState.currentIndex), 0);
    await page.clock.runFor(101);
    assert.equal(await page.locator('#next-btn').isDisabled(), false);
    await page.locator('[data-lang="uz"]').click();
    assert.equal(await page.evaluate(() => practiceState.answers.length), 1);
    await page.reload();
    await page.locator('#resume-btn').click();
    assert.equal(await page.evaluate(() => practiceState.answers.length), 1);
    assert.equal(await page.evaluate(() => currentLang), 'uz');
    await page.clock.runFor(5100);
    await page.locator('#next-btn').press('Enter');
    assert.equal(await page.evaluate(() => practiceState.currentIndex), 1);
    assert.equal(await page.evaluate(() => document.activeElement.id), 'q-text');
    for (let i=1; i<4; i++) {
      const right = await page.evaluate(() => practiceState.currentOptions.find(o => o.isCorrect).id);
      await page.locator(`[data-option-id="${right}"]`).click();
      await page.clock.runFor(5100);
      assert.equal(await page.evaluate(() => practiceState.currentIndex), i);
      await page.locator('#next-btn').click();
    }
    assert.ok(await page.locator('#screen-analytics').isVisible());
    assert.equal(await page.locator('#stat-correct').innerText(), '3');
    assert.equal(await page.locator('#stat-wrong').innerText(), '1');
    assert.equal(await page.locator('.mistake-card').count(), 1);
    await page.screenshot({path:path.join(output, 'results-mobile.png'), fullPage:true});
    await page.locator('#lesson-back-btn').click();
    assert.ok(await page.locator('#lesson-kaku').isVisible());
    assert.equal(await page.evaluate(() => document.activeElement.id), 'lesson-kaku');
    await page.reload();
    assert.ok(await page.locator('#screen-analytics').isVisible());
    assert.equal(await page.locator('#stat-correct').innerText(), '3');
    assert.deepEqual(errors, []);
    await context.close();
    console.log('Browser scenarios and 192 lesson/viewport/text-size checks passed. Review screenshots in test-results.');
  } finally { await browser.close(); }
}
main().catch(error => {console.error(error); process.exitCode = 1;}).finally(() => server.close());
