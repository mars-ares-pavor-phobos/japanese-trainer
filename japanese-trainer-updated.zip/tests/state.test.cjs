const test = require('node:test');
const assert = require('node:assert/strict');
const core = require('../core.js');
const session = require('../session.js');

const questions = [1, 2].map(id => ({id, lexeme:'word' + id, partOfSpeech:'verb',
  options:[{id:'yes-' + id, isCorrect:true}, {id:'no-' + id, isCorrect:false}]}));
const bank = session.bankVersion(questions);
const catalog = {lessons:{sample:[1, 2]}, now:12000};
function state() {
  return {active:true, status:'in-progress', topic:'verb', lesson:'sample', mode:'masu',
    shuffledQuestions:questions, currentIndex:0, answers:[], currentOptions:[],
    optionOrders:new Map(questions.map(q => [q.id, [...q.options]]))};
}
function encode(s) {
  return session.encode({language:'uz', topic:'verb', cycles:new Map(), state:s}, bank);
}
function decode(raw, options = {}) {
  return session.decode(raw, questions, bank, core, {...catalog, ...options});
}
function mutate(raw, change) {
  const data = JSON.parse(raw); change(data); return JSON.stringify(data);
}
function random(seed = 7) {
  return () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
}

test('an answer is counted once and stale or unknown choices cannot change it', () => {
  const s = state();
  assert.equal(core.recordAnswer(s, 2, 'yes-2', 10000), null);
  assert.equal(core.recordAnswer(s, 1, 'unknown', 10000), null);
  const answer = core.recordAnswer(s, 1, 'no-1', 10000);
  assert.equal(answer.correct, false);
  assert.equal(answer.answeredAt, 10000);
  assert.equal(core.recordAnswer(s, 1, 'yes-1', 11000), null);
  assert.equal(s.answers.length, 1);
  assert.equal(s.answers[0], answer);
});

test('next stays blocked through 4999 ms and allows a single manual advance at 5000 ms', () => {
  const s = state();
  assert.equal(core.advanceQuestion(s, 1, 10000), false);
  const answer = core.recordAnswer(s, 1, 'yes-1', 10000);
  assert.equal(core.remainingAnswerDelay(answer, 10000), 5000);
  assert.equal(core.remainingAnswerDelay(answer, 14999), 1);
  assert.equal(core.advanceQuestion(s, 1, 14999), false);
  assert.equal(s.currentIndex, 0);
  assert.equal(core.remainingAnswerDelay(answer, 15000), 0);
  assert.equal(s.currentIndex, 0, 'elapsed time itself never advances a question');
  assert.equal(core.advanceQuestion(s, 1, 15000), true);
  assert.equal(core.advanceQuestion(s, 1, 15001), false);
  assert.equal(core.advanceQuestion(s, 2, 15001), false);
  assert.equal(s.currentIndex, 1);
  s.active = false;
  assert.equal(core.recordAnswer(s, 2, 'yes-2', 20000), null);
});

test('reload preserves choices, score, language, option order and the remaining delay', () => {
  const s = state();
  s.optionOrders.set(1, [...questions[0].options].reverse());
  core.recordAnswer(s, 1, 'no-1', 10000);
  const restored = decode(encode(s));
  assert.equal(restored.kind, 'ok');
  assert.equal(restored.language, 'uz');
  assert.equal(restored.state.currentIndex, 0);
  assert.deepEqual(restored.state.optionOrders.get(1).map(o => o.id), ['no-1', 'yes-1']);
  assert.equal(restored.state.answers[0].correct, false);
  assert.equal(restored.state.answers[0].answeredAt, 10000);
  assert.equal(core.remainingAnswerDelay(restored.state.answers[0], 12000), 3000);
  assert.equal(core.advanceQuestion(restored.state, 1, 14999), false);
  assert.equal(core.advanceQuestion(restored.state, 1, 15000), true);
});

test('legacy saves retain progress and start a five-second interval for the restored answer', () => {
  const s = state();
  core.recordAnswer(s, 1, 'yes-1', 10000);
  const old = mutate(encode(s), d => {delete d.session.answers[0].answeredAt; d.bank = 'previous-bank';});
  assert.equal(decode(old).kind, 'outdated');
  const restored = decode(old, {compatibleBanks:['previous-bank']});
  assert.equal(restored.kind, 'ok');
  assert.equal(restored.state.answers[0].correct, true);
  assert.equal(core.remainingAnswerDelay(restored.state.answers[0], 12000), 5000);
  assert.equal(core.advanceQuestion(restored.state, 1, 16999), false);
  assert.equal(core.advanceQuestion(restored.state, 1, 17000), true);
});

test('future timestamps are clamped after clock changes; malformed timestamps are rejected', () => {
  const s = state(); core.recordAnswer(s, 1, 'yes-1', 10000);
  const raw = encode(s);
  const future = decode(mutate(raw, d => {d.session.answers[0].answeredAt = 999999;}));
  assert.equal(future.state.answers[0].answeredAt, 12000);
  assert.equal(core.remainingAnswerDelay(future.state.answers[0], 11000), 5000);
  for (const value of [null, '10000', -1, 1.5, Number.MAX_SAFE_INTEGER + 1]) {
    assert.equal(decode(mutate(raw, d => {d.session.answers[0].answeredAt = value;})).kind, 'invalid');
  }
});

test('completed and exited results survive without trusting stored score or question content', () => {
  const s = state();
  core.recordAnswer(s, 1, 'yes-1', 1000); core.advanceQuestion(s, 1, 6000);
  core.recordAnswer(s, 2, 'no-2', 6000); core.advanceQuestion(s, 2, 11000);
  s.active = false; s.status = 'completed';
  const restored = decode(mutate(encode(s), d => {d.session.answers[1].correct = true;}));
  assert.equal(restored.kind, 'ok');
  assert.equal(restored.state.active, false);
  assert.equal(restored.state.status, 'completed');
  assert.deepEqual(restored.state.answers.map(a => a.correct), [true, false]);
  s.status = 'exited'; s.currentIndex = 1;
  assert.equal(decode(encode(s)).state.status, 'exited');
});

test('invalid continuity, question IDs, option IDs, topic and order are rejected', () => {
  const s = state(); core.recordAnswer(s, 1, 'yes-1', 1000);
  const raw = encode(s);
  const invalidChanges = [
    d => {d.session.currentIndex = 2;},
    d => {d.session.questionIds = [1, 1];},
    d => {d.session.answers[0].qId = 2;},
    d => {d.session.answers[0].optionId = 'missing';},
    d => {d.session.optionOrders[0] = ['yes-1', 'yes-1'];},
    d => {d.session.topic = 'noun';},
    d => {d.session.lesson = 'missing';},
    d => {d.language = 'xx';},
    d => {d.session.status = 'completed';}
  ];
  for (const change of invalidChanges) assert.equal(decode(mutate(raw, change)).kind, 'invalid');
  assert.equal(decode('{').kind, 'invalid');
  assert.equal(decode(null).kind, 'empty');
});

test('only explicitly listed legacy lesson IDs survive curriculum changes and subsequent saves', () => {
  const s = state(); core.recordAnswer(s, 1, 'yes-1', 1000);
  const raw = encode(s);
  const changedCatalog = {lessons:{sample:[2,1]}, legacyLessons:{sample:[1,2]}};
  assert.equal(decode(raw, {lessons:changedCatalog.lessons}).kind, 'invalid');
  const restored = decode(raw, changedCatalog);
  assert.equal(restored.kind, 'ok');
  assert.deepEqual(restored.state.shuffledQuestions.map(q => q.id), [1,2]);
  assert.equal(restored.state.answers[0].correct, true);
  assert.equal(decode(encode(restored.state), changedCatalog).kind, 'ok', 'the legacy lesson remains valid after saving under the current bank');
  const shortened = mutate(raw, d => {d.session.questionIds = [1]; d.session.optionOrders.length = 1;});
  assert.equal(decode(shortened, changedCatalog).kind, 'invalid', 'subsets are not accepted');
  assert.equal(decode(mutate(raw, d => {d.session.lesson = 'missing';}), {
    ...changedCatalog, legacyLessons:{missing:[1,2]}
  }).kind, 'invalid', 'a legacy entry cannot introduce an unrecognized lesson');
  assert.equal(decode(raw, {...changedCatalog, legacyLessons:{sample:[2]}}).kind, 'invalid');
});

test('question cycles preserve unused questions across snapshots without repeating a word in a session', () => {
  const pool = Array.from({length:16}, (_, id) => ({id, lexeme:'word' + (id % 4), partOfSpeech:'verb',
    tense: id % 2 ? 'past' : 'present', polarity:id % 3 ? 'affirmative' : 'negative', difficulty:'easy'}));
  let cycle = core.createQuestionCycle(pool, random());
  const seen = new Set();
  for (let i = 0; i < 4; i++) {
    const drawn = cycle.draw(4);
    assert.equal(drawn.length, 4);
    assert.equal(new Set(drawn.map(q => q.lexeme)).size, 4);
    for (const q of drawn) {assert.equal(seen.has(q.id), false); seen.add(q.id);}
    const snapshot = cycle.snapshot();
    cycle = core.createQuestionCycle(pool, random(i + 1), snapshot);
    assert.deepEqual(cycle.snapshot(), snapshot);
  }
  assert.equal(seen.size, 16);
  assert.equal(cycle.draw(4).length, 4);
  assert.throws(() => core.createQuestionCycle(pool, random(), {remainingIds:[1, 1], previousId:null}));
  assert.throws(() => core.createQuestionCycle(pool, random(), {remainingIds:[99], previousId:null}));
  assert.throws(() => core.createQuestionCycle(pool, random(), {remainingIds:[1], previousId:1}));
});

test('storage failures do not throw and stale attempts are removed when a write fails', () => {
  const accessDenied = session.createStore(() => {throw new Error('blocked');});
  assert.deepEqual(accessDenied.read(), {ok:false});
  assert.equal(accessDenied.write('value'), false);
  assert.equal(accessDenied.clear(), false);
  let removed = null;
  const quota = session.createStore(() => ({setItem() {throw new Error('quota');}, removeItem(key) {removed = key;}}));
  assert.equal(quota.write('value'), false);
  assert.equal(removed, session.KEY);
});
