const {test} = require('node:test');
const assert = require('node:assert/strict');
const verbs = require('../verbs.js');
const questions = require('../questions.js');
const text = html => html.replace(/<rt>.*?<\/rt>/g, '').replace(/<[^>]*>/g, '');

// Expected forms are independent fixtures, including every I-group ending.
const expected = {
  kaku: ['かく','かかない','かいた','かかなかった'],
  oyogu: ['およぐ','およがない','およいだ','およがなかった'],
  hanasu: ['はなす','はなさない','はなした','はなさなかった'],
  matsu: ['まつ','またない','まった','またなかった'],
  shinu: ['しぬ','しなない','しんだ','しななかった'],
  nomu: ['のむ','のまない','のんだ','のまなかった'],
  asobu: ['あそぶ','あそばない','あそんだ','あそばなかった'],
  tsukuru: ['つくる','つくらない','つくった','つくらなかった'],
  kau: ['かう','かわない','かった','かわなかった'],
  iku: ['いく','いかない','いった','いかなかった'],
  aru: ['ある','ない','あった','なかった'],
  taberu: ['たべる','たべない','たべた','たべなかった'],
  miru: ['みる','みない','みた','みなかった'],
  okiru: ['おきる','おきない','おきた','おきなかった'],
  kiru_wear: ['きる','きない','きた','きなかった'],
  kiru_cut: ['きる','きらない','きった','きらなかった'],
  suru: ['する','しない','した','しなかった'],
  kuru: ['くる','こない','きた','こなかった'],
  benkyou: ['べんきょうする','べんきょうしない','べんきょうした','べんきょうしなかった']
};
test('four forms cover all nine I-group endings and difficult lexical groups', () => {
  for (const [id, forms] of Object.entries(expected))
    assert.deepEqual(verbs.byId[id].forms.map(form => form.reading), forms, id);
  for (const id of ['miru','okiru','kiru_wear']) assert.equal(verbs.byId[id].group, 2);
  for (const id of ['kaeru','hairu','kiru_cut']) assert.equal(verbs.byId[id].group, 1);
  assert.equal(verbs.byId.kuru.group, 3);
});

test('all 240 main questions and 200 lesson questions have unique identities and one answer', () => {
  assert.deepEqual(questions.map(q => q.id), Array.from({length:240}, (_, i) => i + 1));
  const bank = [...questions, ...verbs.verbs.flatMap(verbs.practice)];
  assert.equal(bank.length, 440);
  assert.equal(new Set(bank.map(q => q.id)).size, bank.length);
  for (const q of bank) {
    assert.equal(q.options.filter(o => o.isCorrect).length, 1, `answer ${q.id}`);
    assert.equal(new Set(q.options.map(o => o.id)).size, q.options.length, `option IDs ${q.id}`);
    assert.equal(new Set(q.options.map(o => text(o.html))).size, q.options.length, `options ${q.id}`);
    for (const lang of ['ru','uz']) {
      for (const field of ['prompt','context','explanation']) assert.ok(q[field][lang], `${field} ${lang} ${q.id}`);
      assert.match(q.prompt[lang], / → /, `explicit task ${q.id}`);
    }
    assert.equal(q.dialogue.map(line => line.text).join('').split('____').length - 1, 1, `blank ${q.id}`);
  }
});

test('all 180 nonverb answers agree with the stated form and start from familiar です', () => {
  for (const q of questions.filter(q => q.partOfSpeech !== 'verb')) {
    const index = (q.tense === 'past' ? 2 : 0) + (q.polarity === 'negative' ? 1 : 0);
    const base = q.lexeme;
    const forms = q.partOfSpeech === 'i-adj'
      ? base === 'いい' ? ['いい','よくない','よかった','よくなかった']
        : [base, base.slice(0,-1)+'くない', base.slice(0,-1)+'かった', base.slice(0,-1)+'くなかった']
      : ['だ','じゃない','だった','じゃなかった'].map(ending => base + ending);
    assert.equal(text(q.options.find(o => o.isCorrect).html), forms[index], `answer ${q.id}`);
    for (const lang of ['ru','uz']) {
      assert.ok(text(q.prompt[lang]).startsWith(base + 'です → '), `source ${q.id}/${lang}`);
      assert.ok(q.explanation[lang].includes('です'), `formation ${q.id}/${lang}`);
    }
  }
});

test('standard equivalent answers and ambiguous colour nouns are not marked wrong', () => {
  for (const q of questions) {
    const correct = text(q.options.find(o => o.isCorrect).html);
    const equivalents = new Set([correct]);
    if (correct.includes('じゃ')) equivalents.add(correct.replace('じゃ', 'では'));
    if (correct === 'いい') equivalents.add('よい');
    if ([119,120,121,122].includes(q.id)) equivalents.add(correct.slice(0,-1) + 'だ');
    if (q.id === 36) equivalents.add('好きくない');
    if (q.id === 43) equivalents.add('上手くない');
    for (const o of q.options.filter(o => !o.isCorrect)) assert.ok(!equivalents.has(text(o.html)), `ambiguous ${q.id}`);
  }
});

test('every verb walkthrough begins at ます and reaches its expected full form', () => {
  for (const verb of verbs.verbs) {
    for (let i=0; i<4; i++) {
      const steps = verbs.steps(verb, i);
      assert.equal(steps[0].from, verb.masu.reading, `${verb.id}/${i} source`);
      assert.equal(steps.at(-1).to, verb.forms[i].reading, `${verb.id}/${i} target`);
      for (let j=1; j<steps.length; j++) assert.equal(steps[j].from, steps[j-1].to);
    }
  }
});

test('furigana is attached only to kanji and educational text has no banned punctuation', () => {
  const bank = [...questions,...verbs.verbs.flatMap(verbs.practice)];
  for (const q of bank) {
    const data = JSON.stringify(q);
    assert.doesNotMatch(data, /[—–«»]/u, `punctuation ${q.id}`);
    for (const [,base,reading] of data.matchAll(/<ruby>(.*?)<rt>(.*?)<\/rt><\/ruby>/g)) {
      assert.match(base, /^[\p{Script=Han}々〆ヶ]+$/u, `ruby ${q.id}: ${base}`);
      assert.match(reading, /^[\p{Script=Hiragana}\p{Script=Katakana}ー]+$/u, `reading ${q.id}`);
    }
  }
});
