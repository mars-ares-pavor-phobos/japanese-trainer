const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const verbs = require('../verbs.js');
const source = fs.readFileSync(path.join(__dirname, '../script.js'), 'utf8');
const labelFunctions = source.slice(0, source.indexOf('const i18n'));
const context = vm.createContext({TrainerVerbs:verbs});
vm.runInContext(labelFunctions + fs.readFileSync(path.join(__dirname, '../lessons.js'), 'utf8') + '\nthis.lessons = VerbLessons;', context);
const keys = ['group1','group2','group3','iadj','naadj','noun'];
function render(key, lang) {vm.runInContext(`currentLang = '${lang}'`, context); return context.lessons.render(key);}

test('all six lessons in both languages show complete, labelled matrices before detailed rules', () => {
  for (const lang of ['ru','uz']) for (const key of keys) {
    const html = render(key, lang);
    assert.doesNotMatch(html, /<details|plain-cell|undefined|NaN|[«»—–]/);
    assert.ok(html.indexOf('form-matrix') < html.indexOf('rule-table'), `${lang}/${key}`);
    for (const table of html.matchAll(/<table\b[\s\S]*?<\/table>/g)) {
      assert.equal((table[0].match(/scope="col"/g) || []).length, 3);
      if (table[0].includes('form-matrix')) {
        assert.match(table[0], /<caption>[\s\S]+<\/caption>/);
        assert.equal((table[0].match(/scope="row"/g) || []).length, 2);
        assert.equal((table[0].match(/<td>/g) || []).length, 4);
      }
    }
    const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]);
    assert.equal(new Set(ids).size, ids.length);
    for (const ruby of html.matchAll(/<ruby>(.*?)<rt>(.*?)<\/rt><\/ruby>/g)) {
      assert.match(ruby[1], /^[\p{Script=Han}々]+$/u);
    }
  }
});

test('I-group rules retain every ending, underline changes, and keep exception words visible', () => {
  const html = render('group1','ru');
  for (const ending of ['います','きます','ぎます','します','ちます','にます','びます','みます','ります']) assert.ok(html.includes(`<u>${ending}</u>`), ending);
  assert.match(html, /id="lesson-aru"/);
  assert.match(html, /id="lesson-iku"/);
  assert.match(html, /かか.*なかった/);
  assert.ok(render('group2','uz').includes('id="lesson-kiru_wear"'));
});

test('labels use language-aware Title Case without changing educational prose', () => {
  for (const [lang,input,expected] of [
    ['ru','слова и выражения','Слова и Выражения'],
    ['ru','правила и исключения','Правила и Исключения'],
    ['ru','выберите ответ клавишами','Выберите Ответ Клавишами'],
    ['uz','qoidalar va istisnolar','Qoidalar va Istisnolar'],
    ['uz','mavzular bo‘yicha natijalar','Mavzular bo‘yicha Natijalar']
  ]) assert.equal(vm.runInContext(`titleCaseLabel(${JSON.stringify(input)}, '${lang}')`, context), expected);
  assert.ok(render('noun','ru').includes('Существительное не спрягается.'));
  assert.ok(render('noun','uz').includes('Ot tuslanmaydi.'));
});
